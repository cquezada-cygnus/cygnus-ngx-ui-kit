export type IconSize = "3rem" | "2rem" | "1.875rem" | "1.5rem" | "1.25rem" | "1rem" | "0.875rem" | "0.75rem";
export type IconTextSize = "xxxxl" | "xxxl" | "xxl" | "xl" | "lg" | "" | "sm" | "xs";
export type IconColorText = "white" | "lightgray" | "mediumgray" | "gray" | "secgray" | "thrgray" | "lightblack" | "black" | "lightblue" | "lightmediumblue" | "mediumblue" | "blue" | "lightgreen" | "green" | "lightamber" | "amber" | "lightred" | "mediumred" | "red" | "cygnus" | "yellow" | "postulaaqui-orange";
export type IconColor = "#ffffff" | "#98A2B3" | "#667085" | '#475467' | '#364153' | "#344054" | '#1D2939' | '#101828' | "#2970ff" | "#155eef" | "#1447e6" | '#193cb8' | '#12b76a' | '#008236' | "#f79009" | '#a65f00' | '#f04438' | "#e7000b" | '#c10007' | "#cc5224" | "#fdb022" | '#ED622B';
