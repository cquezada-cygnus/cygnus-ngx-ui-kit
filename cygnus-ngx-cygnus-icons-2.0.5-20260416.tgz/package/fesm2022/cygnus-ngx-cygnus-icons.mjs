import * as i0 from '@angular/core';
import { HostBinding, Input, ChangeDetectionStrategy, Component, signal, input, effect } from '@angular/core';
import * as i1 from '@angular/platform-browser';

class MaskSvgIconComponent {
    sanitizer;
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    path = '';
    get maskImage() {
        return this.sanitizer.bypassSecurityTrustStyle(`url(${this.path})`);
    }
    get webkitMaskImage() {
        return this.sanitizer.bypassSecurityTrustStyle(`url(${this.path})`);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.15", ngImport: i0, type: MaskSvgIconComponent, deps: [{ token: i1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.15", type: MaskSvgIconComponent, isStandalone: true, selector: "lib-mask-svg-icon", inputs: { path: "path" }, host: { properties: { "style.mask-image": "this.maskImage", "style.-webkit-mask-image": "this.webkitMaskImage" } }, ngImport: i0, template: ``, isInline: true, styles: [":host{mask-size:contain;mask-position:center;mask-repeat:no-repeat;-webkit-mask-size:contain;-webkit-mask-position:center;-webkit-mask-repeat:no-repeat}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.15", ngImport: i0, type: MaskSvgIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-mask-svg-icon', imports: [], template: ``, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{mask-size:contain;mask-position:center;mask-repeat:no-repeat;-webkit-mask-size:contain;-webkit-mask-position:center;-webkit-mask-repeat:no-repeat}\n"] }]
        }], ctorParameters: () => [{ type: i1.DomSanitizer }], propDecorators: { path: [{
                type: Input
            }], maskImage: [{
                type: HostBinding,
                args: ['style.mask-image']
            }], webkitMaskImage: [{
                type: HostBinding,
                args: ['style.-webkit-mask-image']
            }] } });

var iconRoutes = [
	{
		"chevron-down": "assets/icons/backups/chevron-down.svg",
		"cygnus-logo": "assets/icons/backups/cygnus-logo.svg",
		info: "assets/icons/backups/info.svg",
		trash: "assets/icons/backups/trash.svg",
		"eye-slash": "assets/icons/heroicons-outline/eye-slash.svg",
		"alert-circle": "assets/icons/svg/Alerts&Feedback/alert-circle.svg",
		"alert-hexagon": "assets/icons/svg/Alerts&Feedback/alert-hexagon.svg",
		"alert-octagon": "assets/icons/svg/Alerts&Feedback/alert-octagon.svg",
		"alert-square": "assets/icons/svg/Alerts&Feedback/alert-square.svg",
		"alert-triangle": "assets/icons/svg/Alerts&Feedback/alert-triangle.svg",
		"alert-question-circle": "assets/icons/svg/Alerts&Feedback/alert-question-circle.svg",
		"announcement-01": "assets/icons/svg/Alerts&Feedback/announcement-01.svg",
		"announcement-02": "assets/icons/svg/Alerts&Feedback/announcement-02.svg",
		"announcement-03": "assets/icons/svg/Alerts&Feedback/announcement-03.svg",
		"bell-01": "assets/icons/svg/Alerts&Feedback/bell-01.svg",
		"bell-02": "assets/icons/svg/Alerts&Feedback/bell-02.svg",
		"bell-03": "assets/icons/svg/Alerts&Feedback/bell-03.svg",
		"bell-04": "assets/icons/svg/Alerts&Feedback/bell-04.svg",
		"bell-minus": "assets/icons/svg/Alerts&Feedback/bell-minus.svg",
		"bell-off-01": "assets/icons/svg/Alerts&Feedback/bell-off-01.svg",
		"bell-off-02": "assets/icons/svg/Alerts&Feedback/bell-off-02.svg",
		"bell-off-03": "assets/icons/svg/Alerts&Feedback/bell-off-03.svg",
		"bell-plus": "assets/icons/svg/Alerts&Feedback/bell-plus.svg",
		"bell-ringing-01": "assets/icons/svg/Alerts&Feedback/bell-ringing-01.svg",
		"bell-ringing-02": "assets/icons/svg/Alerts&Feedback/bell-ringing-02.svg",
		"bell-ringing-03": "assets/icons/svg/Alerts&Feedback/bell-ringing-03.svg",
		"bell-ringing-04": "assets/icons/svg/Alerts&Feedback/bell-ringing-04.svg",
		"notification-box": "assets/icons/svg/Alerts&Feedback/notification-box.svg",
		"notification-message": "assets/icons/svg/Alerts&Feedback/notification-message.svg",
		"notification-text": "assets/icons/svg/Alerts&Feedback/notification-text.svg",
		"thumbs-down": "assets/icons/svg/Alerts&Feedback/thumbs-down.svg",
		"thumbs-up": "assets/icons/svg/Alerts&Feedback/thumbs-up.svg",
		"arrow-block-down": "assets/icons/svg/Arrows/arrow-block-down.svg",
		"arrow-block-left": "assets/icons/svg/Arrows/arrow-block-left.svg",
		"arrow-block-right": "assets/icons/svg/Arrows/arrow-block-right.svg",
		"arrow-block-up": "assets/icons/svg/Arrows/arrow-block-up.svg",
		"arrow-circle-broken-down-left": "assets/icons/svg/Arrows/arrow-circle-broken-down-left.svg",
		"arrow-circle-broken-down-right": "assets/icons/svg/Arrows/arrow-circle-broken-down-right.svg",
		"arrow-circle-broken-down": "assets/icons/svg/Arrows/arrow-circle-broken-down.svg",
		"arrow-circle-broken-left": "assets/icons/svg/Arrows/arrow-circle-broken-left.svg",
		"arrow-circle-broken-right": "assets/icons/svg/Arrows/arrow-circle-broken-right.svg",
		"arrow-circle-broken-up-left": "assets/icons/svg/Arrows/arrow-circle-broken-up-left.svg",
		"arrow-circle-broken-up-right": "assets/icons/svg/Arrows/arrow-circle-broken-up-right.svg",
		"arrow-circle-broken-up": "assets/icons/svg/Arrows/arrow-circle-broken-up.svg",
		"arrow-circle-down-left": "assets/icons/svg/Arrows/arrow-circle-down-left.svg",
		"arrow-circle-down-right": "assets/icons/svg/Arrows/arrow-circle-down-right.svg",
		"arrow-circle-down": "assets/icons/svg/Arrows/arrow-circle-down.svg",
		"arrow-circle-left": "assets/icons/svg/Arrows/arrow-circle-left.svg",
		"arrow-circle-right": "assets/icons/svg/Arrows/arrow-circle-right.svg",
		"arrow-circle-up-left": "assets/icons/svg/Arrows/arrow-circle-up-left.svg",
		"arrow-circle-up-right": "assets/icons/svg/Arrows/arrow-circle-up-right.svg",
		"arrow-circle-up": "assets/icons/svg/Arrows/arrow-circle-up.svg",
		"arrow-down-left": "assets/icons/svg/Arrows/arrow-down-left.svg",
		"arrow-down-right": "assets/icons/svg/Arrows/arrow-down-right.svg",
		"arrow-down": "assets/icons/svg/Arrows/arrow-down.svg",
		"arrow-left": "assets/icons/svg/Arrows/arrow-left.svg",
		"arrow-narrow-down-left": "assets/icons/svg/Arrows/arrow-narrow-down-left.svg",
		"arrow-narrow-down-right": "assets/icons/svg/Arrows/arrow-narrow-down-right.svg",
		"arrow-narrow-down": "assets/icons/svg/Arrows/arrow-narrow-down.svg",
		"arrow-narrow-left": "assets/icons/svg/Arrows/arrow-narrow-left.svg",
		"arrow-narrow-right": "assets/icons/svg/Arrows/arrow-narrow-right.svg",
		"arrow-narrow-up-left": "assets/icons/svg/Arrows/arrow-narrow-up-left.svg",
		"arrow-narrow-up-right": "assets/icons/svg/Arrows/arrow-narrow-up-right.svg",
		"arrow-narrow-up": "assets/icons/svg/Arrows/arrow-narrow-up.svg",
		"arrow-right": "assets/icons/svg/Arrows/arrow-right.svg",
		"arrow-square-down-left": "assets/icons/svg/Arrows/arrow-square-down-left.svg",
		"arrow-square-down-right": "assets/icons/svg/Arrows/arrow-square-down-right.svg",
		"arrow-square-down": "assets/icons/svg/Arrows/arrow-square-down.svg",
		"arrow-square-left": "assets/icons/svg/Arrows/arrow-square-left.svg",
		"arrow-square-right": "assets/icons/svg/Arrows/arrow-square-right.svg",
		"arrow-square-up-left": "assets/icons/svg/Arrows/arrow-square-up-left.svg",
		"arrow-square-up-right": "assets/icons/svg/Arrows/arrow-square-up-right.svg",
		"arrow-square-up": "assets/icons/svg/Arrows/arrow-square-up.svg",
		"arrow-up-left": "assets/icons/svg/Arrows/arrow-up-left.svg",
		"arrow-up-right": "assets/icons/svg/Arrows/arrow-up-right.svg",
		"arrow-up": "assets/icons/svg/Arrows/arrow-up.svg",
		"arrows-down": "assets/icons/svg/Arrows/arrows-down.svg",
		"arrows-left": "assets/icons/svg/Arrows/arrows-left.svg",
		"arrows-right": "assets/icons/svg/Arrows/arrows-right.svg",
		"arrows-triangle": "assets/icons/svg/Arrows/arrows-triangle.svg",
		"arrows-up": "assets/icons/svg/Arrows/arrows-up.svg",
		"chevron-down-double": "assets/icons/svg/Arrows/chevron-down-double.svg",
		"chevron-left-double": "assets/icons/svg/Arrows/chevron-left-double.svg",
		"chevron-left": "assets/icons/svg/Arrows/chevron-left.svg",
		"chevron-right-double": "assets/icons/svg/Arrows/chevron-right-double.svg",
		"chevron-right": "assets/icons/svg/Arrows/chevron-right.svg",
		"chevron-selector-horizontal": "assets/icons/svg/Arrows/chevron-selector-horizontal.svg",
		"chevron-selector-vertical": "assets/icons/svg/Arrows/chevron-selector-vertical.svg",
		"chevron-up-double": "assets/icons/svg/Arrows/chevron-up-double.svg",
		"chevron-up": "assets/icons/svg/Arrows/chevron-up.svg",
		"corner-down-left": "assets/icons/svg/Arrows/corner-down-left.svg",
		"corner-down-right": "assets/icons/svg/Arrows/corner-down-right.svg",
		"corner-left-down": "assets/icons/svg/Arrows/corner-left-down.svg",
		"corner-left-up": "assets/icons/svg/Arrows/corner-left-up.svg",
		"corner-right-down": "assets/icons/svg/Arrows/corner-right-down.svg",
		"corner-right-up": "assets/icons/svg/Arrows/corner-right-up.svg",
		"corner-up-left": "assets/icons/svg/Arrows/corner-up-left.svg",
		"corner-up-right": "assets/icons/svg/Arrows/corner-up-right.svg",
		"expand-01": "assets/icons/svg/Arrows/expand-01.svg",
		"expand-02": "assets/icons/svg/Arrows/expand-02.svg",
		"expand-03": "assets/icons/svg/Arrows/expand-03.svg",
		"expand-04": "assets/icons/svg/Arrows/expand-04.svg",
		"expand-05": "assets/icons/svg/Arrows/expand-05.svg",
		"expand-06": "assets/icons/svg/Arrows/expand-06.svg",
		"flip-backward": "assets/icons/svg/Arrows/flip-backward.svg",
		"flip-forward": "assets/icons/svg/Arrows/flip-forward.svg",
		"Group-1": "assets/icons/svg/Arrows/Group-1.svg",
		infinity: "assets/icons/svg/Arrows/infinity.svg",
		"refresh-ccw-01": "assets/icons/svg/Arrows/refresh-ccw-01.svg",
		"refresh-ccw-02": "assets/icons/svg/Arrows/refresh-ccw-02.svg",
		"refresh-ccw-03": "assets/icons/svg/Arrows/refresh-ccw-03.svg",
		"refresh-ccw-04": "assets/icons/svg/Arrows/refresh-ccw-04.svg",
		"refresh-ccw-05": "assets/icons/svg/Arrows/refresh-ccw-05.svg",
		"refresh-cw-01": "assets/icons/svg/Arrows/refresh-cw-01.svg",
		"refresh-cw-02": "assets/icons/svg/Arrows/refresh-cw-02.svg",
		"refresh-cw-03": "assets/icons/svg/Arrows/refresh-cw-03.svg",
		"refresh-cw-04": "assets/icons/svg/Arrows/refresh-cw-04.svg",
		"refresh-cw-05": "assets/icons/svg/Arrows/refresh-cw-05.svg",
		"reverse-left": "assets/icons/svg/Arrows/reverse-left.svg",
		"reverse-right": "assets/icons/svg/Arrows/reverse-right.svg",
		"switch-horizontal-01": "assets/icons/svg/Arrows/switch-horizontal-01.svg",
		"switch-horizontal-02": "assets/icons/svg/Arrows/switch-horizontal-02.svg",
		"switch-vertical-01": "assets/icons/svg/Arrows/switch-vertical-01.svg",
		"switch-vertical-02": "assets/icons/svg/Arrows/switch-vertical-02.svg",
		"bar-chart-01": "assets/icons/svg/Charts/bar-chart-01.svg",
		"bar-chart-02": "assets/icons/svg/Charts/bar-chart-02.svg",
		"bar-chart-03": "assets/icons/svg/Charts/bar-chart-03.svg",
		"bar-chart-04": "assets/icons/svg/Charts/bar-chart-04.svg",
		"bar-chart-05": "assets/icons/svg/Charts/bar-chart-05.svg",
		"bar-chart-06": "assets/icons/svg/Charts/bar-chart-06.svg",
		"bar-chart-07": "assets/icons/svg/Charts/bar-chart-07.svg",
		"bar-chart-08": "assets/icons/svg/Charts/bar-chart-08.svg",
		"bar-chart-09": "assets/icons/svg/Charts/bar-chart-09.svg",
		"bar-chart-10": "assets/icons/svg/Charts/bar-chart-10.svg",
		"bar-chart-11": "assets/icons/svg/Charts/bar-chart-11.svg",
		"bar-chart-12": "assets/icons/svg/Charts/bar-chart-12.svg",
		"bar-chart-circle-01": "assets/icons/svg/Charts/bar-chart-circle-01.svg",
		"bar-chart-circle-02": "assets/icons/svg/Charts/bar-chart-circle-02.svg",
		"bar-chart-circle-03": "assets/icons/svg/Charts/bar-chart-circle-03.svg",
		"bar-chart-square-01": "assets/icons/svg/Charts/bar-chart-square-01.svg",
		"bar-chart-square-02": "assets/icons/svg/Charts/bar-chart-square-02.svg",
		"bar-chart-square-03": "assets/icons/svg/Charts/bar-chart-square-03.svg",
		"bar-chart-square-down": "assets/icons/svg/Charts/bar-chart-square-down.svg",
		"bar-chart-square-minus": "assets/icons/svg/Charts/bar-chart-square-minus.svg",
		"bar-chart-square-plus": "assets/icons/svg/Charts/bar-chart-square-plus.svg",
		"bar-chart-square-up": "assets/icons/svg/Charts/bar-chart-square-up.svg",
		"bar-line-chart": "assets/icons/svg/Charts/bar-line-chart.svg",
		"chart-breakout-circle": "assets/icons/svg/Charts/chart-breakout-circle.svg",
		"chart-breakout-square": "assets/icons/svg/Charts/chart-breakout-square.svg",
		"horizontal-bar-chart-01": "assets/icons/svg/Charts/horizontal-bar-chart-01.svg",
		"horizontal-bar-chart-02": "assets/icons/svg/Charts/horizontal-bar-chart-02.svg",
		"horizontal-bar-chart-03": "assets/icons/svg/Charts/horizontal-bar-chart-03.svg",
		"line-chart-down-01": "assets/icons/svg/Charts/line-chart-down-01.svg",
		"line-chart-down-02": "assets/icons/svg/Charts/line-chart-down-02.svg",
		"line-chart-down-03": "assets/icons/svg/Charts/line-chart-down-03.svg",
		"line-chart-down-04": "assets/icons/svg/Charts/line-chart-down-04.svg",
		"line-chart-down-05": "assets/icons/svg/Charts/line-chart-down-05.svg",
		"line-chart-up-01": "assets/icons/svg/Charts/line-chart-up-01.svg",
		"line-chart-up-02": "assets/icons/svg/Charts/line-chart-up-02.svg",
		"line-chart-up-03": "assets/icons/svg/Charts/line-chart-up-03.svg",
		"line-chart-up-04": "assets/icons/svg/Charts/line-chart-up-04.svg",
		"line-chart-up-05": "assets/icons/svg/Charts/line-chart-up-05.svg",
		"pie-chart-01": "assets/icons/svg/Charts/pie-chart-01.svg",
		"pie-chart-02": "assets/icons/svg/Charts/pie-chart-02.svg",
		"pie-chart-03": "assets/icons/svg/Charts/pie-chart-03.svg",
		"pie-chart-04": "assets/icons/svg/Charts/pie-chart-04.svg",
		"presentation-chart-01": "assets/icons/svg/Charts/presentation-chart-01.svg",
		"presentation-chart-02": "assets/icons/svg/Charts/presentation-chart-02.svg",
		"presentation-chart-03": "assets/icons/svg/Charts/presentation-chart-03.svg",
		"trend-down-01": "assets/icons/svg/Charts/trend-down-01.svg",
		"trend-down-02": "assets/icons/svg/Charts/trend-down-02.svg",
		"trend-up-01": "assets/icons/svg/Charts/trend-up-01.svg",
		"trend-up-02": "assets/icons/svg/Charts/trend-up-02.svg",
		"annotation-alert": "assets/icons/svg/Communication/annotation-alert.svg",
		"annotation-check": "assets/icons/svg/Communication/annotation-check.svg",
		"annotation-dots": "assets/icons/svg/Communication/annotation-dots.svg",
		"annotation-heart": "assets/icons/svg/Communication/annotation-heart.svg",
		"annotation-info": "assets/icons/svg/Communication/annotation-info.svg",
		"annotation-plus": "assets/icons/svg/Communication/annotation-plus.svg",
		"annotation-question": "assets/icons/svg/Communication/annotation-question.svg",
		"annotation-x": "assets/icons/svg/Communication/annotation-x.svg",
		annotation: "assets/icons/svg/Communication/annotation.svg",
		"inbox-01": "assets/icons/svg/Communication/inbox-01.svg",
		"inbox-02": "assets/icons/svg/Communication/inbox-02.svg",
		"mail-01": "assets/icons/svg/Communication/mail-01.svg",
		"mail-02": "assets/icons/svg/Communication/mail-02.svg",
		"mail-03": "assets/icons/svg/Communication/mail-03.svg",
		"mail-04": "assets/icons/svg/Communication/mail-04.svg",
		"mail-05": "assets/icons/svg/Communication/mail-05.svg",
		"message-alert-circle": "assets/icons/svg/Communication/message-alert-circle.svg",
		"message-alert-square": "assets/icons/svg/Communication/message-alert-square.svg",
		"message-chat-circle": "assets/icons/svg/Communication/message-chat-circle.svg",
		"message-chat-square": "assets/icons/svg/Communication/message-chat-square.svg",
		"message-check-circle": "assets/icons/svg/Communication/message-check-circle.svg",
		"message-check-square": "assets/icons/svg/Communication/message-check-square.svg",
		"message-circle-01": "assets/icons/svg/Communication/message-circle-01.svg",
		"message-circle-02": "assets/icons/svg/Communication/message-circle-02.svg",
		"message-dots-circle": "assets/icons/svg/Communication/message-dots-circle.svg",
		"message-dots-square": "assets/icons/svg/Communication/message-dots-square.svg",
		"message-heart-circle": "assets/icons/svg/Communication/message-heart-circle.svg",
		"message-heart-square": "assets/icons/svg/Communication/message-heart-square.svg",
		"message-notification-circle": "assets/icons/svg/Communication/message-notification-circle.svg",
		"message-notification-square": "assets/icons/svg/Communication/message-notification-square.svg",
		"message-plus-circle": "assets/icons/svg/Communication/message-plus-circle.svg",
		"message-plus-square": "assets/icons/svg/Communication/message-plus-square.svg",
		"message-question-circle": "assets/icons/svg/Communication/message-question-circle.svg",
		"message-question-square": "assets/icons/svg/Communication/message-question-square.svg",
		"message-smile-circle": "assets/icons/svg/Communication/message-smile-circle.svg",
		"message-smile-square": "assets/icons/svg/Communication/message-smile-square.svg",
		"message-square-01": "assets/icons/svg/Communication/message-square-01.svg",
		"message-square-02": "assets/icons/svg/Communication/message-square-02.svg",
		"message-text-circle-01": "assets/icons/svg/Communication/message-text-circle-01.svg",
		"message-text-circle-02": "assets/icons/svg/Communication/message-text-circle-02.svg",
		"message-text-square-01": "assets/icons/svg/Communication/message-text-square-01.svg",
		"message-text-square-02": "assets/icons/svg/Communication/message-text-square-02.svg",
		"message-x-circle": "assets/icons/svg/Communication/message-x-circle.svg",
		"message-x-square": "assets/icons/svg/Communication/message-x-square.svg",
		"phone-call-01": "assets/icons/svg/Communication/phone-call-01.svg",
		"phone-call-02": "assets/icons/svg/Communication/phone-call-02.svg",
		"phone-hang-up": "assets/icons/svg/Communication/phone-hang-up.svg",
		"phone-incoming-01": "assets/icons/svg/Communication/phone-incoming-01.svg",
		"phone-incoming-02": "assets/icons/svg/Communication/phone-incoming-02.svg",
		"phone-outgoing-01": "assets/icons/svg/Communication/phone-outgoing-01.svg",
		"phone-outgoing-02": "assets/icons/svg/Communication/phone-outgoing-02.svg",
		"phone-pause": "assets/icons/svg/Communication/phone-pause.svg",
		"phone-plus": "assets/icons/svg/Communication/phone-plus.svg",
		"phone-x": "assets/icons/svg/Communication/phone.svg",
		phone: "assets/icons/svg/Communication/phone.svg",
		"send-01": "assets/icons/svg/Communication/send-01.svg",
		"send-02": "assets/icons/svg/Communication/send-02.svg",
		"send-03": "assets/icons/svg/Communication/send-03.svg",
		"activity-heart": "assets/icons/svg/General/activity-heart.svg",
		activity: "assets/icons/svg/General/activity.svg",
		anchor: "assets/icons/svg/General/anchor.svg",
		archive: "assets/icons/svg/General/archive.svg",
		"asterisk-01": "assets/icons/svg/General/asterisk-01.svg",
		"asterisk-02": "assets/icons/svg/General/asterisk-02.svg",
		"at-sign": "assets/icons/svg/General/at-sign.svg",
		"bookmark-add": "assets/icons/svg/General/bookmark-add.svg",
		"bookmark-check": "assets/icons/svg/General/bookmark-check.svg",
		"bookmark-minus": "assets/icons/svg/General/bookmark-minus.svg",
		"bookmark-x": "assets/icons/svg/General/bookmark-x.svg",
		bookmark: "assets/icons/svg/General/bookmark.svg",
		"building-01": "assets/icons/svg/General/building-01.svg",
		"building-02": "assets/icons/svg/General/building-02.svg",
		"building-03": "assets/icons/svg/General/building-03.svg",
		"building-04": "assets/icons/svg/General/building-04.svg",
		"building-05": "assets/icons/svg/General/building-05.svg",
		"building-06": "assets/icons/svg/General/building-06.svg",
		"building-07": "assets/icons/svg/General/building-07.svg",
		"building-08": "assets/icons/svg/General/building-08.svg",
		"check-circle-broken": "assets/icons/svg/General/check-circle-broken.svg",
		"check-circle": "assets/icons/svg/General/check-circle.svg",
		"check-done-01": "assets/icons/svg/General/check-done-01.svg",
		"check-done-02": "assets/icons/svg/General/check-done-02.svg",
		"check-heart": "assets/icons/svg/General/check-heart.svg",
		"check-square-broken": "assets/icons/svg/General/check-square-broken.svg",
		"check-square": "assets/icons/svg/General/check-square.svg",
		"check-verified-01": "assets/icons/svg/General/check-verified-01.svg",
		"check-verified-02": "assets/icons/svg/General/check-verified-02.svg",
		"check-verified-03": "assets/icons/svg/General/check-verified-03.svg",
		check: "assets/icons/svg/General/check.svg",
		"cloud-blank-01": "assets/icons/svg/General/cloud-blank-01.svg",
		"cloud-blank-02": "assets/icons/svg/General/cloud-blank-02.svg",
		"contrast-02": "assets/icons/svg/General/contrast-02.svg",
		"copy-01": "assets/icons/svg/General/copy-01.svg",
		"copy-02": "assets/icons/svg/General/copy-02.svg",
		"copy-03": "assets/icons/svg/General/copy-03.svg",
		"copy-04": "assets/icons/svg/General/copy-04.svg",
		"copy-05": "assets/icons/svg/General/copy-05.svg",
		"copy-06": "assets/icons/svg/General/copy-06.svg",
		"copy-07": "assets/icons/svg/General/copy-07.svg",
		"divide-01": "assets/icons/svg/General/divide-01.svg",
		"divide-02": "assets/icons/svg/General/divide-02.svg",
		"divide-03": "assets/icons/svg/General/divide-03.svg",
		"dots-grid": "assets/icons/svg/General/dots-grid.svg",
		"dots-horizontal": "assets/icons/svg/General/dots-horizontal.svg",
		"dots-vertical": "assets/icons/svg/General/dots-vertical.svg",
		"download-01": "assets/icons/svg/General/download-01.svg",
		"download-02": "assets/icons/svg/General/download-02.svg",
		"download-03": "assets/icons/svg/General/download-03.svg",
		"download-04": "assets/icons/svg/General/download-04.svg",
		"download-cloud-01": "assets/icons/svg/General/download-cloud-01.svg",
		"download-cloud-02": "assets/icons/svg/General/download-cloud-02.svg",
		"edit-01": "assets/icons/svg/General/edit-01.svg",
		"edit-02": "assets/icons/svg/General/edit-02.svg",
		"edit-03": "assets/icons/svg/General/edit-03.svg",
		"edit-04": "assets/icons/svg/General/edit-04.svg",
		"edit-05": "assets/icons/svg/General/edit-05.svg",
		"equal-not": "assets/icons/svg/General/equal-not.svg",
		equal: "assets/icons/svg/General/equal.svg",
		"eye-off": "assets/icons/svg/General/eye-off.svg",
		eye: "assets/icons/svg/General/eye.svg",
		"filter-funnel-01": "assets/icons/svg/General/filter-funnel-01.svg",
		"filter-funnel-02": "assets/icons/svg/General/filter-funnel-02.svg",
		"filter-lines": "assets/icons/svg/General/filter-lines.svg",
		"google-chrome": "assets/icons/svg/General/google-chrome.svg",
		"hash-01": "assets/icons/svg/General/hash-01.svg",
		"hash-02": "assets/icons/svg/General/hash-02.svg",
		"heart-circle": "assets/icons/svg/General/heart-circle.svg",
		"heart-hand": "assets/icons/svg/General/heart-hand.svg",
		"heart-hexagon": "assets/icons/svg/General/heart-hexagon.svg",
		"heart-octagon": "assets/icons/svg/General/heart-octagon.svg",
		"heart-rounded": "assets/icons/svg/General/heart-rounded.svg",
		"heart-square": "assets/icons/svg/General/heart-square.svg",
		heart: "assets/icons/svg/General/heart.svg",
		hearts: "assets/icons/svg/General/hearts.svg",
		"help-circle": "assets/icons/svg/General/help-circle.svg",
		"help-hexagon": "assets/icons/svg/General/help-hexagon.svg",
		"help-octagon": "assets/icons/svg/General/help-octagon.svg",
		"help-square": "assets/icons/svg/General/help-square.svg",
		"home-01": "assets/icons/svg/General/home-01.svg",
		"home-02": "assets/icons/svg/General/home-02.svg",
		"home-03": "assets/icons/svg/General/home-03.svg",
		"home-04": "assets/icons/svg/General/home-04.svg",
		"home-05": "assets/icons/svg/General/home-05.svg",
		"home-line": "assets/icons/svg/General/home-line.svg",
		"home-smile": "assets/icons/svg/General/home-smile.svg",
		"info-circle": "assets/icons/svg/General/info-circle.svg",
		"info-hexagon": "assets/icons/svg/General/info-hexagon.svg",
		"info-octagon": "assets/icons/svg/General/info-octagon.svg",
		"info-square": "assets/icons/svg/General/info-square.svg",
		"life-buoy-01": "assets/icons/svg/General/life-buoy-01.svg",
		"life-buoy-02": "assets/icons/svg/General/life-buoy-02.svg",
		"link-01": "assets/icons/svg/General/link-01.svg",
		"link-02": "assets/icons/svg/General/link-02.svg",
		"link-03": "assets/icons/svg/General/link-03.svg",
		"link-04": "assets/icons/svg/General/link-04.svg",
		"link-05": "assets/icons/svg/General/link-05.svg",
		"link-broken-01": "assets/icons/svg/General/link-broken-01.svg",
		"link-broken-02": "assets/icons/svg/General/link-broken-02.svg",
		"link-external-01": "assets/icons/svg/General/link-external-01.svg",
		"link-external-02": "assets/icons/svg/General/link-external-02.svg",
		"loading-01": "assets/icons/svg/General/loading-01.svg",
		"loading-02": "assets/icons/svg/General/loading-02.svg",
		"loading-03": "assets/icons/svg/General/loading-03.svg",
		"log-in-01": "assets/icons/svg/General/log-in-01.svg",
		"log-in-02": "assets/icons/svg/General/log-in-02.svg",
		"log-in-03": "assets/icons/svg/General/log-in-03.svg",
		"log-in-04": "assets/icons/svg/General/log-in-04.svg",
		"log-out-01": "assets/icons/svg/General/log-out-01.svg",
		"log-out-02": "assets/icons/svg/General/log-out-02.svg",
		"log-out-03": "assets/icons/svg/General/log-out-03.svg",
		"log-out-04": "assets/icons/svg/General/log-out-04.svg",
		"luggage-02": "assets/icons/svg/General/luggage-02.svg",
		"marker-pin-04": "assets/icons/svg/General/marker-pin-04.svg",
		"medical-circle": "assets/icons/svg/General/medical-circle.svg",
		"medical-cross": "assets/icons/svg/General/medical-cross.svg",
		"medical-square": "assets/icons/svg/General/medical-square.svg",
		"menu-01": "assets/icons/svg/General/menu-01.svg",
		"menu-02": "assets/icons/svg/General/menu-02.svg",
		"menu-03": "assets/icons/svg/General/menu-03.svg",
		"menu-04": "assets/icons/svg/General/menu-04.svg",
		"menu-05": "assets/icons/svg/General/menu-05.svg",
		mic: "assets/icons/svg/General/mic.svg",
		"minus-circle": "assets/icons/svg/General/minus-circle.svg",
		"minus-square": "assets/icons/svg/General/minus-square.svg",
		minus: "assets/icons/svg/General/minus.svg",
		"percent-01": "assets/icons/svg/General/percent-01.svg",
		"percent-02": "assets/icons/svg/General/percent-02.svg",
		"percent-03": "assets/icons/svg/General/percent-03.svg",
		"pin-01": "assets/icons/svg/General/pin-01.svg",
		"pin-02": "assets/icons/svg/General/pin-02.svg",
		placeholder: "assets/icons/svg/General/placeholder.svg",
		"play-square": "assets/icons/svg/General/play-square.svg",
		"plus-circle": "assets/icons/svg/General/plus-circle.svg",
		"plus-square": "assets/icons/svg/General/plus-square.svg",
		plus: "assets/icons/svg/General/plus.svg",
		"receipt-check": "assets/icons/svg/General/receipt-check.svg",
		"roller-brush": "assets/icons/svg/General/roller-brush.svg",
		"save-01": "assets/icons/svg/General/save-01.svg",
		"save-02": "assets/icons/svg/General/save-02.svg",
		"save-03": "assets/icons/svg/General/save-03.svg",
		"search-lg": "assets/icons/svg/General/search-lg.svg",
		"search-md": "assets/icons/svg/General/search-md.svg",
		"search-refraction": "assets/icons/svg/General/search-refraction.svg",
		"search-sm": "assets/icons/svg/General/search-sm.svg",
		"settings-01": "assets/icons/svg/General/settings-01.svg",
		"settings-02": "assets/icons/svg/General/settings-02.svg",
		"settings-03": "assets/icons/svg/General/settings-03.svg",
		"settings-04": "assets/icons/svg/General/settings-04.svg",
		"share-01": "assets/icons/svg/General/share-01.svg",
		"share-02": "assets/icons/svg/General/share-02.svg",
		"share-03": "assets/icons/svg/General/share-03.svg",
		"share-04": "assets/icons/svg/General/share-04.svg",
		"share-05": "assets/icons/svg/General/share-05.svg",
		"share-06": "assets/icons/svg/General/share-06.svg",
		"share-07": "assets/icons/svg/General/share-07.svg",
		"shopping-bag-01": "assets/icons/svg/General/shopping-bag-01.svg",
		"slash-circle-01": "assets/icons/svg/General/slash-circle-01.svg",
		"slash-circle-02": "assets/icons/svg/General/slash-circle-02.svg",
		"slash-divider": "assets/icons/svg/General/slash-divider.svg",
		"slash-octagon": "assets/icons/svg/General/slash-octagon.svg",
		"speedometer-01": "assets/icons/svg/General/speedometer-01.svg",
		"speedometer-02": "assets/icons/svg/General/speedometer-02.svg",
		"speedometer-03": "assets/icons/svg/General/speedometer-03.svg",
		"speedometer-04": "assets/icons/svg/General/speedometer-04.svg",
		"stop-circle": "assets/icons/svg/General/stop-circle.svg",
		"target-01": "assets/icons/svg/General/target-01.svg",
		"target-02": "assets/icons/svg/General/target-02.svg",
		"target-03": "assets/icons/svg/General/target-03.svg",
		"target-04": "assets/icons/svg/General/target-04.svg",
		"target-05": "assets/icons/svg/General/target-05.svg",
		"toggle-01-left": "assets/icons/svg/General/toggle-01-left.svg",
		"toggle-01-right": "assets/icons/svg/General/toggle-01-right.svg",
		"toggle-02-left": "assets/icons/svg/General/toggle-02-left.svg",
		"toggle-02-right": "assets/icons/svg/General/toggle-02-right.svg",
		"toggle-03-left": "assets/icons/svg/General/toggle-03-left.svg",
		"toggle-03-right": "assets/icons/svg/General/toggle-03-right.svg",
		"tool-01": "assets/icons/svg/General/tool-01.svg",
		"tool-02": "assets/icons/svg/General/tool-02.svg",
		"translate-01": "assets/icons/svg/General/translate-01.svg",
		"translate-02": "assets/icons/svg/General/translate-02.svg",
		"trash-01": "assets/icons/svg/General/trash-01.svg",
		"trash-02": "assets/icons/svg/General/trash-02.svg",
		"trash-03": "assets/icons/svg/General/trash-03.svg",
		"trash-04": "assets/icons/svg/General/trash-04.svg",
		"upload-01": "assets/icons/svg/General/upload-01.svg",
		"upload-02": "assets/icons/svg/General/upload-02.svg",
		"upload-03": "assets/icons/svg/General/upload-03.svg",
		"upload-04": "assets/icons/svg/General/upload-04.svg",
		"upload-cloud-01": "assets/icons/svg/General/upload-cloud-01.svg",
		"upload-cloud-02": "assets/icons/svg/General/upload-cloud-02.svg",
		virus: "assets/icons/svg/General/virus.svg",
		"x-circle": "assets/icons/svg/General/x-circle.svg",
		"x-close": "assets/icons/svg/General/x-close.svg",
		"x-square": "assets/icons/svg/General/x-square.svg",
		x: "assets/icons/svg/General/x.svg",
		"zap-circle": "assets/icons/svg/General/zap-circle.svg",
		"zap-fast": "assets/icons/svg/General/zap-fast.svg",
		"zap-off": "assets/icons/svg/General/zap-off.svg",
		"zap-square": "assets/icons/svg/General/zap-square.svg",
		zap: "assets/icons/svg/General/zap.svg",
		"alarm-clock-check": "assets/icons/svg/Time/alarm-clock-check.svg",
		"alarm-clock-minus": "assets/icons/svg/Time/alarm-clock-minus.svg",
		"alarm-clock-off": "assets/icons/svg/Time/alarm-clock-off.svg",
		"alarm-clock-plus": "assets/icons/svg/Time/alarm-clock-plus.svg",
		"alarm-clock": "assets/icons/svg/Time/alarm-clock.svg",
		"calendar-check-01": "assets/icons/svg/Time/calendar-check-01.svg",
		"calendar-check-02": "assets/icons/svg/Time/calendar-check-02.svg",
		"calendar-date": "assets/icons/svg/Time/calendar-date.svg",
		"calendar-heart-01": "assets/icons/svg/Time/calendar-heart-01.svg",
		"calendar-heart-02": "assets/icons/svg/Time/calendar-heart-02.svg",
		"calendar-minus-01": "assets/icons/svg/Time/calendar-minus-01.svg",
		"calendar-minus-02": "assets/icons/svg/Time/calendar-minus-02.svg",
		"calendar-plus-01": "assets/icons/svg/Time/calendar-plus-01.svg",
		"calendar-plus-02": "assets/icons/svg/Time/calendar-plus-02.svg",
		calendar: "assets/icons/svg/Time/calendar.svg",
		"clock-check": "assets/icons/svg/Time/clock-check.svg",
		"clock-fast-forward": "assets/icons/svg/Time/clock-fast-forward.svg",
		"clock-plus": "assets/icons/svg/Time/clock-plus.svg",
		"clock-refresh": "assets/icons/svg/Time/clock-refresh.svg",
		"clock-rewind": "assets/icons/svg/Time/clock-rewind.svg",
		"clock-snooze": "assets/icons/svg/Time/clock-snooze.svg",
		"clock-stopwatch": "assets/icons/svg/Time/clock-stopwatch.svg",
		clock: "assets/icons/svg/Time/clock.svg",
		"hourglass-01": "assets/icons/svg/Time/hourglass-01.svg",
		"hourglass-02": "assets/icons/svg/Time/hourglass-02.svg",
		"hourglass-03": "assets/icons/svg/Time/hourglass-03.svg",
		"watch-circle": "assets/icons/svg/Time/watch-circle.svg",
		"watch-square": "assets/icons/svg/Time/watch-square.svg",
		"face-content": "assets/icons/svg/Users/face-content.svg",
		"face-frown": "assets/icons/svg/Users/face-frown.svg",
		"face-happy": "assets/icons/svg/Users/face-happy.svg",
		"face-neutral": "assets/icons/svg/Users/face-neutral.svg",
		"face-sad": "assets/icons/svg/Users/face-sad.svg",
		"face-smile": "assets/icons/svg/Users/face-smile.svg",
		"face-wink": "assets/icons/svg/Users/face-wink.svg",
		"user-01": "assets/icons/svg/Users/user-01.svg",
		"user-02": "assets/icons/svg/Users/user-02.svg",
		"user-03": "assets/icons/svg/Users/user-03.svg",
		"user-check-01": "assets/icons/svg/Users/user-check-01.svg",
		"user-check-02": "assets/icons/svg/Users/user-check-02.svg",
		"user-circle": "assets/icons/svg/Users/user-circle.svg",
		"user-down-01": "assets/icons/svg/Users/user-down-01.svg",
		"user-down-02": "assets/icons/svg/Users/user-down-02.svg",
		"user-edit": "assets/icons/svg/Users/user-edit.svg",
		"user-left-01": "assets/icons/svg/Users/user-left-01.svg",
		"user-left-02": "assets/icons/svg/Users/user-left-02.svg",
		"user-minus-01": "assets/icons/svg/Users/user-minus-01.svg",
		"user-minus-02": "assets/icons/svg/Users/user-minus-02.svg",
		"user-plus-01": "assets/icons/svg/Users/user-plus-01.svg",
		"user-plus-02": "assets/icons/svg/Users/user-plus-02.svg",
		"user-right-01": "assets/icons/svg/Users/user-right-01.svg",
		"user-right-02": "assets/icons/svg/Users/user-right-02.svg",
		"user-square": "assets/icons/svg/Users/user-square.svg",
		"user-up-01": "assets/icons/svg/Users/user-up-01.svg",
		"user-up-02": "assets/icons/svg/Users/user-up-02.svg",
		"user-x-01": "assets/icons/svg/Users/user-x-01.svg",
		"user-x-02": "assets/icons/svg/Users/user-x-02.svg",
		"users-01": "assets/icons/svg/Users/users-01.svg",
		"users-02": "assets/icons/svg/Users/users-02.svg",
		"users-03": "assets/icons/svg/Users/users-03.svg",
		"users-check": "assets/icons/svg/Users/users-check.svg",
		"users-down": "assets/icons/svg/Users/users-down.svg",
		"users-edit": "assets/icons/svg/Users/users-edit.svg",
		"users-left": "assets/icons/svg/Users/users-left.svg",
		"users-minus": "assets/icons/svg/Users/users-minus.svg",
		"users-plus": "assets/icons/svg/Users/users-plus.svg",
		"users-right": "assets/icons/svg/Users/users-right.svg",
		"users-up": "assets/icons/svg/Users/users-up.svg",
		"users-x": "assets/icons/svg/Users/users-x.svg",
		"cloud-01": "assets/icons/svg/Weather/cloud-01.svg",
		"moon-01": "assets/icons/svg/Weather/moon-01.svg",
		sun: "assets/icons/svg/Weather/sun.svg",
		"Featured-icon": "assets/icons/Featured-icon.svg",
		"logo-cygnus": "assets/icons/logo-cygnus.svg",
		file: "assets/icons/file.svg",
		"bg-bottom-min": "assets/img/bg-bottom-min.svg",
		"bg-bottom": "assets/img/bg-bottom.svg",
		"bg-sidebar": "assets/img/bg-sidebar.svg",
		sidebar: "assets/img/sidebar.svg",
		star: "assets/img/star.svg",
		accessible: "assets/img/accessible.svg",
		"accessible-03": "assets/img/accessible-03.svg"
	}
];

var ICONS = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: iconRoutes
});

class NgxCygnusIconsComponent {
    width = signal('1rem');
    height = signal('1rem');
    color = signal('#193cb8');
    route = signal('assets/icons/svg/Users/user-check-02.svg');
    size = input('lg');
    textColor = input('blue');
    textRoute = input('');
    constructor() {
        effect(() => {
            this.setSize();
            this.setColor();
            this.setRoute();
        });
    }
    ngOnInit() {
        this.setSize();
        this.setColor();
        this.setRoute();
    }
    setSize() {
        switch (this.size()) {
            case 'xs':
                this.width.set('0.75rem');
                this.height.set('0.75rem');
                break;
            case 'sm':
                this.width.set('0.875rem');
                this.height.set('0.875rem');
                break;
            case '':
                this.width.set('1rem');
                this.height.set('1rem');
                break;
            case 'lg':
                this.width.set('1.25rem');
                this.height.set('1.25rem');
                break;
            case 'xl':
                this.width.set('1.5rem');
                this.height.set('1.5rem');
                break;
            case 'xxl':
                this.width.set('1.875rem');
                this.height.set('1.875rem');
                break;
            case 'xxxl':
                this.width.set('2rem');
                this.height.set('2rem');
                break;
            case 'xxxxl':
                this.width.set('3rem');
                this.height.set('3rem');
                break;
            default:
                this.width.set('1rem');
                this.height.set('1rem');
                break;
        }
    }
    setColor() {
        switch (this.textColor()) {
            case 'white':
                this.color.set('#ffffff');
                break;
            case 'lightgray':
                this.color.set('#98A2B3');
                break;
            case 'mediumgray':
                this.color.set('#667085');
                break;
            case 'gray':
                this.color.set('#475467');
                break;
            case 'secgray':
                this.color.set('#364153');
                break;
            case 'thrgray':
                this.color.set('#344054');
                break;
            case 'lightblack':
                this.color.set('#1D2939');
                break;
            case 'black':
                this.color.set('#101828');
                break;
            case 'lightblue':
                this.color.set('#2970ff');
                break;
            case 'seclightblue':
                this.color.set('#8ec5ff');
                break;
            case 'lightmediumblue':
                this.color.set('#155eef');
                break;
            case 'mediumblue':
                this.color.set('#1447e6');
                break;
            case 'blue':
                this.color.set('#193cb8');
                break;
            case 'lightgreen':
                this.color.set('#12b76a');
                break;
            case 'green':
                this.color.set('#008236');
                break;
            case 'lightamber':
                this.color.set('#f79009');
                break;
            case 'amber':
                this.color.set('#a65f00');
                break;
            case 'lightred':
                this.color.set('#f04438');
                break;
            case 'mediumred':
                this.color.set('#e7000b');
                break;
            case 'red':
                this.color.set('#c10007');
                break;
            case 'cygnus':
                this.color.set('#cc5224');
                break;
            case 'yellow':
                this.color.set('#fdb022');
                break;
            case 'postulaaqui-orange':
                this.color.set('#ED622B');
                break;
            case 'indigo':
                this.color.set('#5145CD');
                break;
            default: // string
                this.color.set(this.textColor());
                break;
        }
    }
    setRoute() {
        const checkRoute = this.textRoute();
        if (checkRoute.includes('/') || checkRoute.includes('\\')) { // si es una ruta, buscar el ícono en esa ruta
            this.route.set(checkRoute);
        }
        else { // si no, se considera que el usuario ha entregado una palabra clave y debemos buscar la ruta asociada a esa palabra clave
            const ICONS_ROUTES = JSON.parse(JSON.stringify(ICONS)).default[0];
            if (ICONS_ROUTES.hasOwnProperty(checkRoute)) {
                this.route.set(ICONS_ROUTES[checkRoute]);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.15", ngImport: i0, type: NgxCygnusIconsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.15", type: NgxCygnusIconsComponent, isStandalone: true, selector: "lib-ngx-cygnus-icons", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, textColor: { classPropertyName: "textColor", publicName: "textColor", isSignal: true, isRequired: false, transformFunction: null }, textRoute: { classPropertyName: "textRoute", publicName: "textRoute", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
  <lib-mask-svg-icon
    [style.background-color]="color()"
    [style.height]="height()"
    [style.width]="width()"
    [path]="route()"
  />`, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: MaskSvgIconComponent, selector: "lib-mask-svg-icon", inputs: ["path"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.15", ngImport: i0, type: NgxCygnusIconsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-ngx-cygnus-icons', imports: [MaskSvgIconComponent], template: `
  <lib-mask-svg-icon
    [style.background-color]="color()"
    [style.height]="height()"
    [style.width]="width()"
    [path]="route()"
  />`, styles: [":host{display:inline-flex}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Public API Surface of ngx-cygnus-icons
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxCygnusIconsComponent };
//# sourceMappingURL=cygnus-ngx-cygnus-icons.mjs.map
