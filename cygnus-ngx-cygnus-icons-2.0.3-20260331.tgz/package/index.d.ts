/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@cygnus/ngx-cygnus-icons" />
export * from './public-api';
