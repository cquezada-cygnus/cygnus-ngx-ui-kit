# Ngx Cygnus Icons

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 19.2.0.

## Cómo instalar ngx-cygnus-icons en un proyecto angular

1. Compilación de la librería: En la raíz del proyecto, ejecutar en consola

```bash
ng build ngx-cygnus-icons
```

o bien

```bash
ng build --project=ngx-cygnus-icons
```

2. Empaquetar la librería

```bash
cd dist/ngx-cygnus-icons
npm pack
```

Esto generará un archivo comprimido.


3. Cortar el archivo comprimido generado y dejarlo en la raiz de la app angular donde se quiere instalar.

4. Ejecutar en consola (x.x.x corresponde a la versión del proyecto)

```bash
npm install ./ngx-cygnus-icons-x.x.x.tgz
```

5. Revisar la referencia a la librería instalada en package.json y en la carpeta node_modules.



## Cómo utilizar ngx-cygnus-icons una vez instalado

1. En cada componente que vaya a utilizar ngx-cygnus-icons se debe importar el componente que maneja los íconos:

```
import { NgxCygnusIconsComponent } from '@cygnus/ngx-cygnus-icons';

@Component({
  ...,
  imports: [
    NgxCygnusIconsComponent,
  ],
})
```

2. Configurar angular.json del proyecto donde se ejecutará la ngx-cygnus-icons para que muestre los íconos:

```
"options": {
    "assets": [
                  ...,
                  {
                    "glob": "**/*",
                    "input": "node_modules/@cygnus/ngx-cygnus-icons/assets",
                    "output": "/assets/"
                  }
                ],
}
```
