import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class MaskSvgIconComponent {
    private sanitizer;
    constructor(sanitizer: DomSanitizer);
    path: string;
    get maskImage(): SafeStyle;
    get webkitMaskImage(): SafeStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaskSvgIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaskSvgIconComponent, "lib-mask-svg-icon", never, { "path": { "alias": "path"; "required": false; }; }, {}, never, never, true, never>;
}
