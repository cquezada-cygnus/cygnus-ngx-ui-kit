import { OnInit } from '@angular/core';
import { IconSize, IconTextSize } from './types/icon.types';
import * as i0 from "@angular/core";
export declare class NgxCygnusIconsComponent implements OnInit {
    width: import("@angular/core").WritableSignal<IconSize>;
    height: import("@angular/core").WritableSignal<IconSize>;
    color: import("@angular/core").WritableSignal<string>;
    route: import("@angular/core").WritableSignal<string>;
    size: import("@angular/core").InputSignal<IconTextSize>;
    textColor: import("@angular/core").InputSignal<string>;
    textRoute: import("@angular/core").InputSignal<string>;
    constructor();
    ngOnInit(): void;
    setSize(): void;
    setColor(): void;
    setRoute(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxCygnusIconsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxCygnusIconsComponent, "lib-ngx-cygnus-icons", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "textColor": { "alias": "textColor"; "required": false; "isSignal": true; }; "textRoute": { "alias": "textRoute"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
