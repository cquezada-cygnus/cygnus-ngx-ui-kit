export * from './lib/ngx-cygnus-icons.component';
export type { IconTextSize, IconColorText } from './lib/types/icon.types';
